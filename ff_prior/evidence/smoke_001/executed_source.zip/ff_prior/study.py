"""Explicit, gated held-out study and strict-pool verification; never automatic."""
from dataclasses import asdict
from pathlib import Path
import time
import numpy as np
from .storage import read_json,atomic_json,digest,RunLock
from .contracts import assert_frozen,strict_pool
from .spline import from_arrays
from .model_gates import evaluate_reference
from .coupled_predictor import pose_errors
from .physical_audit import audit_execution


def verify_strict_pool(pool,archive_root,output,robot,initial,collision,profile,remaining_steps):
    """Validate every member of an externally frozen root-attempt pool.

    A pool is an explicit inverse-planning input, not five forward-generated
    goals. At most 40 root attempts are accepted; retimings share a root.
    """
    task=pool["task"]
    assert_frozen(task)
    candidates=pool["candidates"]
    if len({c["root_id"] for c in candidates})>40 or pool.get("frozen_before_verification") is not True:
        raise ValueError("strict root-attempt/frozen-pool contract")
    validated, references = [],{}
    for c in candidates:
        with np.load(Path(archive_root)/c["reference_npz"]) as data:
            reference=from_arrays(data)
        prediction,report=evaluate_reference(robot,initial,reference,collision,profile)
        p,r=(pose_errors(prediction["ee"][-1],task["condition"]["goals"]) if prediction is not None else (np.array([1e30]),np.array([1e30])))
        eligible=report["validation_level"]=="MODEL_VALID" and np.all(p<=profile.position_error_m) and np.all(r<=profile.rotation_error_rad)
        validated.append({"sample_id":c["sample_id"],"root_id":c["root_id"],"task_hash":task["task_hash"],
            "validation_level":"MODEL_VALID" if eligible else "REJECTED","path":reference.evaluate(np.linspace(0,reference.duration,128)),
            "report":report,"frozen_goal_position_error_m":p,"frozen_goal_rotation_error_rad":r})
        references[c["sample_id"]]=reference
    terminal={}
    quota=strict_pool(validated,terminal)
    steps=0
    if quota=="INCOMPLETE_POOL_VERIFICATION":
        for c in validated:
            if c["validation_level"]!="MODEL_VALID":
                terminal[c["sample_id"]]="EXECUTION_FAILED"
                continue
            ref=references[c["sample_id"]]
            required=2*int(round((ref.duration+ref.hold)/robot.model.opt.timestep))
            if steps+required>remaining_steps:
                terminal[c["sample_id"]]="BUDGET_EXHAUSTED"
                continue
            report=audit_execution(task,profile,robot,initial,ref,Path(output)/c["sample_id"])
            steps+=required
            terminal[c["sample_id"]]=report["level"]
    result={"status":strict_pool(validated,terminal),"quota_before_execution":quota,"candidates":validated,
        "terminal_results":terminal,"physics_steps_including_replay":steps,"five_physical_successes_required":False,
        "all_frozen_candidates_accounted":len(validated)==len(candidates),"task_hash":task["task_hash"]}
    atomic_json(Path(output)/"strict_pool.json",result)
    return result


def run_study(config,archive,budget_path,checkpoint,output,dry_run=False):
    from .pipeline import audit,acceptance
    from .benchmark import plan,METHODS
    archive=Path(archive)
    bank=read_json(archive)
    budget=read_json(budget_path)
    required={"wall_seconds","physics_steps_including_replay","task_count","strict_task_count","candidate_count","ddim_steps"}
    if set(budget)!=required or budget["task_count"]!=200 or budget["strict_task_count"]!=20 or budget["candidate_count"]!=5:
        raise ValueError("study requires explicit frozen 200 TEST / 20 strict / five-candidate budget")
    if len(bank.get("tasks",[]))!=200 or len(bank.get("strict_pools",[]))!=20 or bank.get("split")!="TEST":
        raise ValueError("frozen study archive must contain 200 TEST tasks and 20 strict pools")
    if bank.get("selection_independent_of_tested_methods") is not True or bank.get("frozen_before_planning") is not True:
        raise ValueError("unfrozen or method-selected test archive")
    gate=config.get("explicit_scaleup_evidence")
    if not gate or read_json(gate).get("STUDY_ELIGIBLE") is not True:
        raise ValueError("study requires completed explicit pilot evidence")
    for entry in bank["tasks"]:
        assert_frozen(entry)
    if dry_run:
        return {"status":"DRY_RUN","archive_hash":digest(bank),"budget":budget}
    output=Path(output)
    with RunLock(output):
        baseline,robot,initial,collision=audit(config)
        profile=acceptance(config)
        atomic_json(output/"frozen_inputs.json",{"archive_hash":digest(bank),"budget":budget,"baseline":baseline})
        start=time.perf_counter()
        steps=0
        records=[]
        for index,task in enumerate(bank["tasks"]):
            for method in METHODS:
                identity=f"task_{index:03d}_{method}"
                if time.perf_counter()-start>=budget["wall_seconds"]:
                    records.append({"id":identity,"status":"BUDGET_EXHAUSTED"})
                    continue
                result=plan(task,checkpoint,{"candidates":5,"ddim_steps":budget["ddim_steps"]},robot,initial,collision,profile,method,20261015+index)
                atomic_json(output/identity/"planning.json",result)
                selected=result["selected_id"]
                status="NO_MODEL_VALID_FROZEN_GOAL_CANDIDATE"
                if selected is not None:
                    from .spline import Reference
                    ref=Reference(result["candidates"][selected]["Z"],np.asarray(task["condition"]["initial_features"]),task["condition"]["duration"])
                    required_steps=2*int(round((ref.duration+ref.hold)/robot.model.opt.timestep))
                    if steps+required_steps<=budget["physics_steps_including_replay"]:
                        execution=audit_execution(task,profile,robot,initial,ref,output/identity/"execution")
                        status=execution["level"]; steps+=required_steps
                    else:
                        status="BUDGET_EXHAUSTED"
                records.append({"id":identity,"status":status})
                atomic_json(output/"progress.json",{"results":records,"physics_steps":steps})
        strict=[]
        for index,pool in enumerate(bank["strict_pools"]):
            if time.perf_counter()-start>=budget["wall_seconds"]:
                strict.append({"status":"BUDGET_EXHAUSTED"}); continue
            result=verify_strict_pool(pool,archive.parent,output/f"strict_{index:03d}",robot,initial,collision,profile,budget["physics_steps_including_replay"]-steps)
            steps+=result["physics_steps_including_replay"]
            strict.append({"status":result["status"]})
        result={"status":"FINISHED","test_task_denominator":200,"strict_task_denominator":20,
            "results":records,"strict":strict,"physics_steps_including_replay":steps,
            "wall_s":time.perf_counter()-start,"benefit":"NOT_ESTABLISHED"}
        atomic_json(output/"study.json",result)
        return result
